﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KursachLib
{
    public interface IPrint
    {
        void Print();
    }
}
