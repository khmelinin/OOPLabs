﻿using System;
using KursachLib;

namespace Kursach
{
    class Program
    {
        
        static void Main(string[] args)
        {
            UI.StartDefault();
            Console.ReadKey();
        }
    }
}
